# Hanna-Marie Weydahl

**Hanna-Marie Weydahl**  (30 June 1922 – 5 January 2016) was a Norwegian pianist.

She was born in Tjøme, and made her concert debut in Oslo in 1940. Among her repertoire was music by Fartein Valen, Harald Sæverud, Klaus Egge, Eivind Groven, Geirr Tveitt, and Alexander Scriabin. She lectured at the Norwegian Academy of Music from 1973 to 1991. She was awarded the Harriet Cohen International Music Award in 1966, and the King's Medal of Merit in gold in 1986.

## References

 1. ^ Bjerkestrand, Nils E. "Hanna-Marie Weydahl".  In Godal, Anne Marit (ed.). Store norske leksikon (in Norwegian). Oslo: Norsk nettleksikon. Retrieved 22 February 2016.


 - ISNI
 - VIAF
 - WorldCat

 - United States

This article about a Norwegian musician is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

