# Jean-François Sauvé

**Jean-François Sauvé**  (born January 23, 1960) is a Canadian former professional ice hockey centre.  He played in the National Hockey League with the Buffalo Sabres and Quebec Nordiques.

## Biography

Sauve was born in Sainte-Geneviève, Quebec. As a youth, he played in the 1972 and 1973 Quebec International Pee-Wee Hockey Tournaments with a minor ice hockey teams from Pierrefonds, Quebec, and from the North shore of Montreal. In his NHL career, Sauvé appeared in 290 games. He scored sixty-five goals and added 138 assists.

Sauvé is the brother of former NHL goaltender Bob Sauvé and the uncle of former NHL goaltender Philippe Sauvé. Sauvé's son Maxime (born 1990) was selected 47th overall by the Boston Bruins in the 2008 NHL Entry Draft, and played one NHL game with the team. His nephew, Philippe Sauvé is a NHL hockey player like his brother, Robert Sauve.

## Career statistics

## References

 1. ^ "Pee-Wee players who have reached NHL or WHA" (PDF). Quebec International Pee-Wee Hockey Tournament. 2018. Archived from the original (PDF) on 2019-03-06. Retrieved 2019-01-10.

 2. ^ Elite Prospects - Maxime Sauvé player profile


## External links

 - Biographical information and career statistics from Eliteprospects.com, or Eurohockey.com, or Hockey-Reference.com, or The Internet Hockey Database



This biographical article relating to a Canadian ice hockey centre born in the 1960s is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

