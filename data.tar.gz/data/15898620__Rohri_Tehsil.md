# Rohri Tehsil

**Rohri Tehsil**   (Urdu: ) is an administrative subdivision (tehsil) of Sukkur District in the Sindh province of Pakistan, the town of Rohri is the capital.

## Administration

Assistant Commissioner of Taluka Rohri is Mr. Awais Mushtaq Khokhar(PAS-42nd CTP). Rohri Taluka is administratively subdivided into 11 Union Councils.

## References

 1. ^ a b Taluka Municipal Administration Rohri Archived 2008-10-13 at the Wayback Machine


 - v
 - t
 - e

 - Badin
 - Matli
 - Shaheed Fazal Rahu
 - Talhar
 - Tando Bago

 - Jati
 - Kharo Chan
 - Mirpur Bathoro
 - Shah Bunder
 - Sujawal

 - Ghorabari
 - Keti Bunder
 - Mirpur Sakro
 - Thatta

 - Dadu
 - Johi
 - Khairpur Nathan Shah
 - Mehar

 - Hyderabad City
 - Hyderabad Saddar
 - Latifabad
 - Qasimabad

 - Jamshoro
 - Kotri
 - Manjhand
 - Sehwan
 - Thano Bula Khan

 - Hala
 - Matiari
 - Saeedabad

 - Chamber
 - Jhando Mari
 - Tando Allahyar

 - Bulri Shah Karim
 - Tando Ghulam Hyder
 - Tando Muhammad Khan

 - Gulberg Town
 - Liaquatabad Town
 - New Karachi Town
 - North Nazimabad Town

 - Gulshan Town
 - Jamshed Town
 - Ferozabad
 - Gulshan-E-Iqbal
 - Gulzar-E-Hijri

 - Lyari Town
 - Saddar Town
 - Aram Bahg
 - Civil Line
 - Garden

 - Baldia Town
 - Kiamari Town
 - S.I.T.E. Town
 - Orangi Town
 - Harbour
 - Manghopir
 - Mauripur
 - Mominabad

 - Korangi Town
 - Landhi Town
 - Shah Faisal Town
 - Madol Colony

 - Bin Qasim Town
 - Gadap Town
 - Malir Town
 - Jinnah
 - Ibrahim Hyderi
 - Murad Memon
 - Shah Murad

 - Garhi Khairo
 - Jacobabad
 - Thul

 - Kandhkot
 - Kashmore
 - Tangwani

 - Bakrani
 - Dokri
 - Larkana
 - Rato Dero

 - Miro Khan
 - Nasirabad
 - Qambar
 - Kubo Saeed Khan
 - Shahdadkot
 - Sijawal Junejo
 - Warah

 - Garhi Yasin
 - Khanpur
 - Lakhi
 - Shikarpur

 - Digri
 - Hussain Bux Marri
 - Jhuddo
 - Kot Ghulam Mohammad
 - Mirpur Khas
 - Shujabad
 - Sindhri

 - Jam Nawaz Ali
 - Khipro
 - Sanghar
 - Shahdadpur
 - Sinjhoro
 - Tando Adam

 - Chachro
 - Dhali
 - Diplo
 - Islamkot
 - Mithi
 - Nagarparkar

 - Kunri
 - Pithoro
 - Samaro
 - Umerkot
 - Uthman Kot

 - Daharki
 - Ghotki
 - Khangarh (Khanpur)
 - Mirpur Mathelo
 - Ubauro

 - Faiz Ganj
 - Gambat
 - Khairpur
 - Kingri
 - Kot Diji
 - Nara
 - Sobho Dero
 - Thari Mirwah

 - New Sukkur
 - Pano Akil
 - Rohri
 - Salehpat
 - Sukkur

 - Bhiria
 - Kandioro
 - Mehrabpur
 - Moro
 - Naushahro Feroze

 - Daulatpur (Qazi Ahmed)
 - Daur
 - Nawabshah
 - Sakrand



This Sindh location article is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

