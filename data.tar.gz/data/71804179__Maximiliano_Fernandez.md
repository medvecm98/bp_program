# Maximiliano Fernandez



**Maximiliano Fernandez**  (born September 29, 1995) is an American pair skater. With his current skating partner, Valentina Plazas, he is the 2022 CS U.S. Classic bronze medalist.

With his former partner, Joy Weinberg, he is the 2016 U.S. junior national champion and finished in the top 10 at the 2016 World Junior Figure Skating Championships.

## Personal lif

Fernandez was born on September 29, 1995, in Hialeah, Florida, to parents Stella, a former ballet dancer, and Alex. He has a sister, Daniella, who also competed in figure skating. Fernandez is of Peruvian descent on his mother's side, and Cuban descent on his father's.

Fernandez is a 2014 graduate of Coral Reef Senior High School and currently attends Miami Dade College.

## Programs

### With Plazas

 - Hold My Hand (from Top Gun: Maverick)  by Lady Gaga  choreo. by Amanda Evora and Jim Peterson

 - Maria  (from West Side Story)  performed by Ansel Elgort  choreo. by Amanda Evora and Jim Peterson

 - Captain America Suite  (from Captain America: The First Avenger)
 - Avengers Suite  (from Avengers: Infinity War)  by Alan Silvestri  choreo. by Amanda Evora and Jim Peterson

 - Wedding Pas de Deux  (The Sleeping Beauty)  by Pyotr Ilyich Tchaikovsky  choreo. by Amanda Evora and Jim Peterson

 - Aladdinby Alan Menkenchoreo. by Amanda Evora, Jim Peterson

 - Steppin' Out with My Baby   by Tony Bennett  choreo. by Amanda Evora and Jim Peterson

 - Aladdinby Alan Menkenchoreo. by Amanda Evora, Jim Peterson

## Competitive highlights

