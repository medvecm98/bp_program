# The Lady Vanishes (disambiguation)

***The Lady Vanishes***  is a 1938 film by Alfred Hitchcock and starring Margaret Lockwood.

***The Lady Vanishes***  may also refer to:

 - The Lady Vanishes (novel) or The Wheel Spins, a 1936 mystery novel by Ethel Lina White
 - The Lady Vanishes (1979 film), a film starring Cybill Shepherd
 - The Lady Vanishes (2013 film), a film starring Tuppence Middleton
 - "The Lady Vanishes", an episode of The Commish
 - "The Lady Vanishes", an episode of Dallas
 - "The Lady Vanishes", a 2012 episode of The Fifth Estate
 - "The Lady Vanishes", an episode of 2point4 children
 - "The Lady Vanishes", an episode of Sexton Blake
 - "The Lady Vanishes", an episode of Wings

