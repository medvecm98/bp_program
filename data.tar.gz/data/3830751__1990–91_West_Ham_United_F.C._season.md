# 1990–91 West Ham United F.C. season



For the **1990–91 West Ham United F.C. season**  in English football, West Ham United finished 2nd in the league.

## Season summary

Billy Bonds in his first full season as manager guided West Ham back to the top flight of The Football League as the team finished second in the Second Division, one point behind Oldham Athletic, who pipped them to the title on the last day of the season. Oldham were the season's top scorers in the division with 83 goals.

West Ham finished the season with the meanest defence, conceding 34 goals. The second meanest defence belonged to 7th place Middlesbrough, containing Colin Cooper and Tony Mowbray, which conceded 47 goals. West Ham's two games against Middlesbrough ended in 0–0 draws.

West Ham also enjoyed their best FA Cup run since the triumph of 1980, reaching the semi-finals where they were beaten 4–0 by Nottingham Forest, denying them a Wembley final with local rivals Tottenham Hotspur who went on to win the trophy.

Trevor Morley was West Ham's leading scorer for 1990–91, with 12 goals in the league and 17 in all competitions, while Frank McAvennie showed full fitness after a long term injury by scoring 10 goals in the league (11 in all competitions) to finish the campaign as the club's second top scorer.

## Results

*West Ham United's score comes first* 

### Football League First Division

### FA Cup

### League Cup

## Squa

## References

 1. ^ a b c "2nd Division 1990-91". www.westhamstats.info. Retrieved 13 March 2012.


 - v
 - t
 - e

 - 1895–96
 - 1896–97
 - 1897–98
 - 1898–99
 - 1899–1900
 - 1900–01
 - 1919–20
 - 1920–21
 - 1921–22
 - 1922–23
 - 1923–24
 - 1924–25
 - 1925–26
 - 1926–27
 - 1927–28
 - 1928–29
 - 1929–30
 - 1930–31
 - 1931–32
 - 1932–33
 - 1933–34
 - 1934–35
 - 1935–36
 - 1936–37
 - 1937–38
 - 1938–39
 - 1939–40
 - 1945–46
 - 1946–47
 - 1947–48
 - 1948–49
 - 1949–50
 - 1950–51
 - 1951–52
 - 1952–53
 - 1953–54
 - 1954–55
 - 1955–56
 - 1956–57
 - 1957–58
 - 1958–59
 - 1959–60
 - 1960–61
 - 1961–62
 - 1962–63
 - 1963–64
 - 1964–65
 - 1965–66
 - 1966–67
 - 1967–68
 - 1968–69
 - 1969–70
 - 1970–71
 - 1971–72
 - 1972–73
 - 1973–74
 - 1974–75
 - 1975–76
 - 1976–77
 - 1977–78
 - 1978–79
 - 1979–80
 - 1980–81
 - 1981–82
 - 1982–83
 - 1983–84
 - 1984–85
 - 1985–86
 - 1986–87
 - 1987–88
 - 1988–89
 - 1989–90
 - 1990–91
 - 1991–92
 - 1992–93
 - 1993–94
 - 1994–95
 - 1995–96
 - 1996–97
 - 1997–98
 - 1998–99
 - 1999–2000
 - 2000–01
 - 2001–02
 - 2002–03
 - 2003–04
 - 2004–05
 - 2005–06
 - 2006–07
 - 2007–08
 - 2008–09
 - 2009–10
 - 2010–11
 - 2011–12
 - 2012–13
 - 2013–14
 - 2014–15
 - 2015–16
 - 2016–17
 - 2017–18
 - 2018–19
 - 2019–20
 - 2020–21
 - 2021–22
 - 2022–23

 - v
 - t
 - e

 - Graham Taylor
 - UEFA Euro 1992
qualification
Group 7

 - qualification
 - Group 7

 - Football League (First Division, Second Division, Third Division, Fourth Division, play-offs)

 - Football Conference

 - Isthmian League (Premier, One)
 - Northern Premier League (Premier, One)
 - Southern League (Premier, Midland, Southern)

 - Isthmian League (Two North, Two South)
 - Combined Counties League (level 8 only)
 - Eastern Counties League (Premier, One)
 - Essex Senior League (level 8 only)
 - Hellenic League (Premier, One)
 - Kent League (level 8 only)
 - Midland Football Combination (level 8 only)
 - North West Counties League (One, Two)
 - Northern Counties East League (Premier, One)
 - Northern League (One, Two)
 - South Midlands League (Premier, One)
 - Spartan League (Premier, One)
 - Sussex County League (One, Two)
 - United Counties League (Premier, One)
 - Wessex League (level 8 only)
 - West Midlands (Regional) League (level 8 only)
 - Western League (Premier, One)

 - FA Cup (Qualifying rounds, Final)
 - Charity Shield
 - FA Trophy (Final)

 - League Cup (Final)
 - Full Members' Cup (Final)
 - Associate Members' Cup (Final)

 - UEFA Cup
 - Cup Winners' Cup

 - Arsenal
 - Aston Villa
 - Chelsea
 - Coventry City
 - Crystal Palace
 - Derby County
 - Everton
 - Leeds United
 - Liverpool
 - Luton Town
 - Manchester City
 - Manchester United
 - Norwich City
 - Nottingham Forest
 - Queens Park Rangers
 - Sheffield United
 - Southampton
 - Sunderland
 - Tottenham Hotspur
 - Wimbledon

 - Barnsley
 - Blackburn Rovers
 - Brighton & Hove Albion
 - Bristol City
 - Bristol Rovers
 - Charlton Athletic
 - Hull City
 - Ipswich Town
 - Leicester City
 - Middlesbrough
 - Millwall
 - Newcastle United
 - Notts County
 - Oldham Athletic
 - Oxford United
 - Plymouth Argyle
 - Port Vale
 - Portsmouth
 - Sheffield Wednesday
 - Swindon Town
 - Watford
 - West Bromwich Albion
 - West Ham United
 - Wolverhampton Wanderers

 - Birmingham City
 - Bolton Wanderers
 - Bournemouth
 - Bradford City
 - Brentford
 - Bury
 - Cambridge United
 - Chester City
 - Crewe Alexandra
 - Exeter City
 - Fulham
 - Grimsby Town
 - Huddersfield Town
 - Leyton Orient
 - Mansfield Town
 - Preston North End
 - Reading
 - Rotherham United
 - Shrewsbury Town
 - Southend United
 - Stoke City
 - Swansea City
 - Tranmere Rovers
 - Wigan Athletic

 - Aldershot
 - Blackpool
 - Burnley
 - Cardiff City
 - Carlisle United
 - Chesterfield
 - Darlington
 - Doncaster Rovers
 - Gillingham
 - Halifax Town
 - Hartlepool United
 - Hereford United
 - Lincoln City
 - Maidstone United
 - Northampton Town
 - Peterborough United
 - Rochdale
 - Scarborough
 - Scunthorpe United
 - Southport
 - Stockport County
 - Torquay United
 - Walsall
 - Wrexham
 - York City

 - Colchester United

