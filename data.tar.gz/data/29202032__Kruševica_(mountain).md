# Kruševica (mountain)

**Kruševica**  (Serbian Cyrillic: Крушевица) is a mountain in southern Serbia, near the town of Vlasotince. Its highest peak, *Vita kruška* , has an elevation of  913 meters above sea level.

## References

 1. ^ a b Jovan Đokić. "Katalog planina Srbije". PSD Kopaonik Beograd. Archived from the original on May 18, 2011.

 2. ^ "Niške planine". Retrieved 2010-08-23.




This Serbia location article is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

