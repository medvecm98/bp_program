# Drahšie bude kúrenie aj jazda autom. Kto bude mať nárok na dotácie?

Jazdiť na aute so spaľovacím motorom a kúriť plynom či uhlím v dome alebo v byte o pár rokov už vôbec nebude také výhodné.

 Európska komisia totiž chce, aby aj výrobcovia neekologických palív platili svoj emisný účet, preto sa ich chystá zaradiť do systému nákup emisných povoleniek - tzv. ETS 2.

Článok pokračuje pod video reklamou

Ten má síce fungovať na princípe "znečisťovateľ platí", firmy však s najväčšou pravdepodobnosťou nové výdavky presunú rovno na plecia spotrebiteľov, ktorým stúpnu účty za kúrenie či tankovanie.
