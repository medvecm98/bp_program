# Ruhleben

This is a disambiguation page. **Ruhleben**  may refer to

 - Ruhleben-Spandau - a district in Berlin, Germany
 - Ruhleben (Berlin U-Bahn) - a Berlin underground station
 - Ruhleben internment camp - a World War I detention camp for enemy civilians
 - Ruhleben Barracks - a German naval barracks in Plön, Holstein

