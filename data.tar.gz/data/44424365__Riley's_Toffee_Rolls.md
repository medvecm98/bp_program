# Riley's Toffee Rolls

**Riley's Toffee Rolls**  were launched in 1907 and made by "Riley Brothers, (Halifax) Limited" from a recipe given to them by their mother.  The brothers were Fred Riley & J.H Riley. They were manufactured at their Hopwood Lane factory in Halifax, West Yorkshire, which is now a McVitie's site.

In 1953, due to the death of J.H. Riley, the surviving brother sold the company to Nuttalls and after a number of corporate purchases the company ended up in control of Kraft PLC and produced at the Callard & Bowser operation at their Bridgend Plant.

In the mid 1990s the decision was made to discontinue production of Riley's Toffee Rolls in favour of increased production of the Altoid mint.

In 2008 Freya Sykes discovered a recipe book called "Economical Cooking" given to her by her Granny Ella Riley; in the front was the hand written recipe which was given to her by her uncles, Fred & J.H. Riley. The recipe was for the original Riley's Toffee Rolls and after filing for IP rights the Riley Toffee Rolls was reborn, now with a slightly softer texture to fit modern taste.





## References

 1. ^ http://www.bbc.co.uk/programmes/b05nsb49 The Food Programme (BBC Radio 4) 29 March 2015.

 2. ^ Town, Toffee. "Riley's Toffees". www.toffeetown.org. Retrieved 16 May 2013.

 3. ^ Zientek, Henryk (14 May 2010). "Ella Riley wins IP rights to Riley's Toffee Rolls". Huddersfield Examiner. Retrieved 14 May 2010.


