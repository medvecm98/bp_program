# 1986–87 Sacramento Kings season

The **1986-87 NBA season**  was the Kings' 38th season in the NBA and second in Sacramento.

## Draft picks

## Roster

 - 
 -   Jerry Reynolds

 - 
 -   Don Buse
 - 
 -   Frank Hamblen

 - (C) Team captain
 - (DP) Unsigned draft pick
 - (FA) Free agent
 - (S) Suspended
 -  Injured

## Regular season

### Season standings

 - v
 - t
 - e

 - v
 - t
 - e



### Record vs. opponents

### Game log

## Player statistics

## Awards and records

## Transactions

## References

 1. ^ 1986-87 Sacramento Kings


## See also

 - 1986-87 NBA season

 - v
 - t
 - e

 - 1986 NBA draft
 - All-Star Game
 - Playoffs
 - Finals
 - Transactions

 - Boston
 - New Jersey
 - New York
 - Philadelphia
 - Washington

 - Atlanta
 - Chicago
 - Cleveland
 - Detroit
 - Indiana
 - Milwaukee

 - Dallas
 - Denver
 - Houston
 - Sacramento
 - San Antonio
 - Utah

 - Golden State
 - L.A. Clippers
 - L.A. Lakers
 - Phoenix
 - Portland
 - Seattle

 - v
 - t
 - e

 - Founded in 1923
 - Formerly the Rochester Seagrams (1923–1942), Rochester Eber Seagrams (1942–1943), Rochester Pros (1943–1945), Rochester Royals (1945–1957), Cincinnati Royals (1957–1972); played in Kansas City-Omaha (1972–1975), Kansas City (1975–1985)
 - Based in Sacramento, California

 - All-time roster
 - Draft history
 - Records
 - Head coaches
 - Seasons
 - Current season

 - Edgerton Park Arena
 - Rochester War Memorial
 - Cincinnati Gardens
 - Kansas City Municipal Auditorium
 - Omaha Civic Auditorium
 - Kemper Arena
 - ARCO Arena I
 - ARCO Arena
 - Golden 1 Center

 - Stockton Kings

 - 1
 - 2
 - 4
 - 6
 - 11
 - 12
 - 14
 - 16
 - 21
 - 27
 - 44

 - 1951

 - Failed relocation attempts
 - Slamson the Lion
 - Maloof family
 - "Love Song" (Tesla song)
 - Maurie
 - Pete Carril and the Princeton offense
 - The Greatest Show on Court
 - Light the Beam!

 - v
 - t
 - e

 - Franchise
 - Seasons

