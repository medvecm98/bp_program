# I'm a Stranger Here Myself

**I'm a Stranger Here Myself**  may refer to:

 - I'm a Stranger Here Myself (1938), a book by Ogden Nash
 - "I'm a Stranger Here Myself" (1943), a song from the musical One Touch of Venus
 - "I'm a Stranger Here Myself" (1951), a short story by science fiction author Mack Reynolds
 - I'm a Stranger Here Myself: The Story of a Welsh Farm (1978), a novel by John Seymour
 - I'm a Stranger Here Myself: Notes on Returning to America After 20 Years Away (1998), a book by travel writer Bill Bryson
 - Sorry, I'm a Stranger Here Myself (1981–1982), a British sitcom

