# Warraber Islet, Queensland



**Warraber Islet**  is an island locality in the Torres Strait Island Region, Queensland, Australia. It consists of a single island, Sue Islet (also known as **Warraber** ), the middle island of The Three Sisters. The only town is Sue Island on the north-west part of the island. In the 2016 census, Warraber Islet had a population of 245 people.

## Education

Warraber Island Campus is a primary (Early Childhood-6) campus of Tagai State College ().

There is no secondary school on the island. The nearest secondary school is on Thursday Island.

## References

 1. ^ a b Australian Bureau of Statistics (27 June 2017). "Warraber Islet (SSC)". 2016 Census QuickStats. Retrieved 20 October 2018. 

 2. ^ "Warraber Islet – locality in Torres Strait Island Region (entry 46709)". Queensland Place Names. Queensland Government. Retrieved 5 November 2019.

 3. ^ "Sue Islet – island in the Torres Strait Island Region (entry 32727)". Queensland Place Names. Queensland Government. Retrieved 10 November 2019.

 4. ^ "Queensland Globe". State of Queensland. Retrieved 8 January 2020.

 5. ^ "State and non-state school details". Queensland Government. 9 July 2018. Archived from the original on 21 November 2018. Retrieved 21 November 2018.

 6. ^ "Tagai State College - Warraber Island Campus". Retrieved 21 November 2018.

 7. ^ "Queensland Globe". State of Queensland. Retrieved 9 November 2019.


 - v
 - t
 - e

 - Badu Island
 - Boigu
 - Boigu Island
 - Burrar Islet
 - Coconut Island
 - Darnley Island
 - Dauan Island
 - Dogai
 - Dowar Islet
 - Erub Island
 - Guijar Islet
 - Hammond Island
 - Iama Island
 - Keriri Island
 - Kubin
 - Mabuiag Island
 - Masig Island
 - Mer Island
 - Moa Island
 - Murray Island
 - Poruma Island
 - Saibai
 - Saibai Island
 - St Pauls
 - Stephens Island
 - Sue Island
 - Ugar Island
 - Warraber Islet
 - Waua Islet
 - Yam Island

