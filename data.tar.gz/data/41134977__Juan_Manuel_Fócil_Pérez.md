# Juan Manuel Fócil Pérez

**Juan Manuel Fócil Pérez**  (born 12 June 1963) is a Mexican politician affiliated with the National Regeneration Movement. As of 2013 he served as Deputy of the LXII Legislature of the Mexican Congress representing Tabasco. Since September 2018 he serves as a Senator in the Senate of the Republic (Mexico), representing the state of Tabasco. 

## References

 1. ^ "Perfil del legislador". Legislative Information System. Retrieved 20 November 2013.


This article about a National Regeneration Movement (Morena) politician is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

