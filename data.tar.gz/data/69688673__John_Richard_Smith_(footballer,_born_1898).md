# John Richard Smith (footballer, born 1898)



**John Richard Smith**  (26 July 1898–1986) was an English footballer who played in the Football League for Aberdare Athletic, Bristol City, Fulham, Plymouth Argyle and Wrexham.

## References

 1. ^ a b c d e John Richard Smith at the English National Football Archive (subscription required)

 2. ^ Joyce, Michael (2004). Football League Players' Records 1888 to 1939. SoccerData. ISBN 1-899468-67-6.

 3. ^ "JACK SMITH". Greens on Screen. Retrieved 6 January 2022.


This biographical article related to association football in England, about a forward born in the 1890s, is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

