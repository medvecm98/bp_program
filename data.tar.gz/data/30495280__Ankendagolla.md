# Ankendagolla

**Ankendagolla**  is a village in Sri Lanka. It is located within Central Province.

## See also

 - List of towns in Central Province, Sri Lanka

## External links

 - Department of Census and Statistics – Sri Lanka



This Nuwara Eliya District, Central Province, Sri Lanka location article is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

