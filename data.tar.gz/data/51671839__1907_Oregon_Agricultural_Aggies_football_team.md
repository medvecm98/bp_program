# 1907 Oregon Agricultural Aggies football team

 - Fred Norcross (2nd season)

 - v
 - t
 - e

The **1907 Oregon Agricultural Aggies football team**  represented Oregon Agricultural College (now known as Oregon State University) as an independent during the 1907 college football season. 

In their second season under head coach Fred Norcross, the Aggies compiled a perfect 6–0 record, did not allow any of their opponents to score, and outscored their opponents by a combined total of 137 to 0. The Aggies' victories included games against Oregon (4–0), the Pacific Boxers (49–0), and Willamette (42–0).

Oregon Agricultural's final game of the season, at St. Vincent's in Los Angeles, was a Thanksgiving Day matchup of the "champions" of the Northwest and the "champions" of California, with the winner taking home the "championship" of the entire West Coast. After beating St. Vincent's, the Aggies' proclaimed themselves "Champions of the Pacific Coast".

This is still the only perfect season in Oregon State history, and moreover, they did not allow a single point this season.

## Schedul

 - College Field
 - Corvallis, OR

 - College Field
 - Corvallis, OR

 - College Field
 - Corvallis, OR

 - Kincaid Field
 - Eugene, OR

 - College Field
 - Corvallis, OR

 - Fiesta Park
 - Los Angeles, CA

## References

 1. ^ "2016 Football Media Guide" (PDF). Oregon State University. pp. 148–149. Retrieved September 20, 2016.

 2. ^ "1907 college football top 25".

 3. ^ "Barometer Football Number 1, 1907".

 4. ^ "There is nothing left for Astoria, O.A.C. defeats Crimsons by score of twenty-six to nothing". The Oregon Daily Journal. October 20, 1907. Retrieved October 23, 2022 – via Newspapers.com.

 5. ^ "Whitworth loses, 6–0". The Tacoma Daily Ledger. October 27, 1907. Retrieved October 23, 2022 – via Newspapers.com.

 6. ^ "Oregon Agrics win an easy victory". The Oregon Daily Journal. November 3, 1907. Retrieved October 23, 2022 – via Newspapers.com.

 7. ^ "Farmers win annual game from Oregon". Eugene Daily Guard. November 9, 1907. Retrieved October 23, 2022 – via Google News Archive.

 8. ^ "Oregon Agricultural College defeats Cardinal and Gold". Oregon Daily Statesman. November 17, 1907. Retrieved October 23, 2022 – via Newspapers.com.

 9. ^ "St. Vincent's loses Coast Intercollegiate championship to Oregon "Aggies"". The Los Angeles Times. November 29, 1907. Retrieved October 23, 2022 – via Newspapers.com.


 - v
 - t
 - e

 - Bell Field (1909–1952)
 - Reser Stadium (1953–present)
 - Multnomah Stadium (alternate)

 - Bowl games
 - Oregon
Platypus Trophy
 - Northwest Championship

 - Platypus Trophy

 - History
 - Benny Beaver
 - "Hail to Old OSU"
 - Marching band
 - Pyramid Play
 - "The Toilet Bowl"
 - 1985 Washington game

 - Head coaches
 - NFL draftees
 - Statistical leaders

 - 1893
 - 1894
 - 1895
 - 1896
 - 1897
 - 1898
 - 1899
 - 1900–1901
 - 1902
 - 1903
 - 1904
 - 1905
 - 1906
 - 1907
 - 1908
 - 1909
 - 1910
 - 1911
 - 1912
 - 1913
 - 1914
 - 1915
 - 1916
 - 1917
 - 1918
 - 1919
 - 1920
 - 1921
 - 1922
 - 1923
 - 1924
 - 1925
 - 1926
 - 1927
 - 1928
 - 1929
 - 1930
 - 1931
 - 1932
 - 1933
 - 1934
 - 1935
 - 1936
 - 1937
 - 1938
 - 1939
 - 1940
 - 1941
 - 1942
 - 1943–1944
 - 1945
 - 1946
 - 1947
 - 1948
 - 1949
 - 1950
 - 1951
 - 1952
 - 1953
 - 1954
 - 1955
 - 1956
 - 1957
 - 1958
 - 1959
 - 1960
 - 1961
 - 1962
 - 1963
 - 1964
 - 1965
 - 1966
 - 1967
 - 1968
 - 1969
 - 1970
 - 1971
 - 1972
 - 1973
 - 1974
 - 1975
 - 1976
 - 1977
 - 1978
 - 1979
 - 1980
 - 1981
 - 1982
 - 1983
 - 1984
 - 1985
 - 1986
 - 1987
 - 1988
 - 1989
 - 1990
 - 1991
 - 1992
 - 1993
 - 1994
 - 1995
 - 1996
 - 1997
 - 1998
 - 1999
 - 2000
 - 2001
 - 2002
 - 2003
 - 2004
 - 2005
 - 2006
 - 2007
 - 2008
 - 2009
 - 2010
 - 2011
 - 2012
 - 2013
 - 2014
 - 2015
 - 2016
 - 2017
 - 2018
 - 2019
 - 2020
 - 2021
 - 2022
 - 2023

This college football 1907 season article is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

This article about a sports team in Oregon is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

