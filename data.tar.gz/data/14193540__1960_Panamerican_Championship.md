# 1960 Panamerican Championship

The **1960 Panamerican Championship**  was the third and final edition of Panamerican Championship, an association football tournament featuring national teams from North, Central and South America. It was hosted in San José, Costa Rica, between March 6 and March 20, in 1960. All the matches were held in Estadio Nacional.

Four teams played as a round-robin tournament, it was won by Argentina.

## Venu

## Final tabl

## Match details





## Top goalscorers

There were 32 goals scored in 12 matches, for an average of 2.67 goals per match.

**3 goals** 

 -  Osvaldo Nardiello
 -  Raúl Belén
 -  Elton
 -  Juarez
 -  Sigifredo Mercado

**2 goals** 

 -  Carlos González



## References

 1. ^ III. Panamerican Championship 1960 by Erik Francisco Lugo and Eduardo Mendoza on the RSSSF

 2. ^ "El día que Costa Rica bailó y goleó a Brasil" on Historias del Fútbol Tico (blogsite)


 - v
 - t
 - e

 - 1952
 - 1956
 - 1960

 - CONCACAF Gold Cup
 - Copa América

