# Athletics at the 2022 Commonwealth Games – Men's 100 metres (T47)





 - v
 - t
 - e

The **
## Records

Prior to this competition, the existing world and Games records were as follows:

## Schedul

The schedule was as follows:



## Results

### First roun

First 3 in each heat (Q) and the next 2 fastest (q) advance to the Final

Wind: Heat 1: -0.6 m/s, Heat 2: -0.9 m/s



### Final

The medals were determined in the final.

Wind: +0.5m/s

## References

 1. ^ "Men's T45-47 100m". Birmingham 2022. 9 August 2022. Retrieved 9 August 2022.

 2. ^ First round results

 3. ^ Final results


