# Saint-Pierre-sur-Orthe

**Saint-Pierre-sur-Orthe**  is a former commune in the Mayenne department in north-western France. On 1 January 2021, it was merged into the new commune Vimartin-sur-Orthe.

## See also

 - Communes of the Mayenne department
 - Parc naturel régional Normandie-Maine

## References

 1. ^ Téléchargement du fichier d'ensemble des populations légales en 2019, INSEE

 2. ^ Des villages de Cassini aux communes d'aujourd'hui: Commune data sheet Saint-Pierre-sur-Orthe, EHESS. (in French)

 3. ^ "Arrêté préfectoral" (PDF). 21 December 2020. Retrieved 6 January 2021.


 - France
 - BnF data



This Mayenne geographical article is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

