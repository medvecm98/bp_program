# Italský premiér podal demisi, prezident rozpustil parlament, zemi čekají předčasné volby

Italský prezident Sergio Mattarella rozpustil parlament. Italové půjdou  předčasně k volbám 25. září, píší italská média i agentura Reuters.  Premiér Mario Draghi podal ve čtvrtek ráno do rukou Mattarelly svou  demisi. Prezident jej požádal, aby kabinet dočasně vedl dál. Draghiho  demise se očekávala po středečním hlasování Senátu o důvěře. Premiér  sice podporu senátorů získal, hlasování se však neúčastnili jeho  spojenci, tři nejsilnější strany. 

Komentátoři předních zahraničních médií jsou k politickému vývoji v  Itálii skeptičtí. Španělský deník El País označil italský parlament za  „sebedestruktivní“. New York Times hovoří o „konci italské éry stability a vlivu“ a vstupu do „chaotické politické sezony“. Podle francouzského  Le Monde nemůže být konec éry Draghiho „horším momentem pro Itálii,  eurozónu, i celou Evropskou unii“.
