# Dave Connell



**Dave Connell**  (born 27 November 1961 in Dublin) was an Irish soccer player during the 1970s and 1980s. He is currently the head coach of the U19 Republic of Ireland women's national football team and works as a Football In Community Development Officer for the Football Association of Ireland.

A classy right back, Connell played for Bohemians, Dundalk and Shamrock Rovers F.C. amongst others during his career in the League of Ireland. He played for Bohs in the famous 3-2 win over Rangers in 1984. He captained Ireland at schoolboys Under 15 level in 1974/75 playing and scoring twice against a Dutch side which included Ruud Gullit, and a Wales side that boasted Ian Rush.

He signed for Rovers in August 1989 and in his three years at the club won two consecutive Player of the Year awards. He made a total of 126 appearances scoring 6 times for the Hoops.

He signed for Ards F.C. and then had a spell at Drogheda United F.C.

He has also played for and  managed Limerick F.C. and having retired from playing managed Galway United in the League of Ireland.

## Honours

 - SRFC Player of the Year: 2
Shamrock Rovers - 1990/91, 1991/92
 - Player of the Year
Bohemians F.C. - 1981/82

 - Shamrock Rovers - 1990/91, 1991/92

 - Bohemians F.C. - 1981/82

## References

 1. ^ "Football Association of Ireland".


## Sources

 - The Hoops by Paul Doolan and Robert Goggins (ISBN 0-7171-2121-6)

 - v
 - t
 - e

 - Amby Fogarty (1976–78)
 - Tommy Callaghan (1978–79)
 - Tommy Lally & Eamonn Deacy (1979)
 - John Herrick (1979–81)
 - Mick Cooke (1981)
 - John Herrick (1981–83)
 - Paddy Mulligan (1983–84)
 - Tommy Lally (1984–85)
 - Tony Mannion (1984–85)
 - John Herrick (1988)
 - Fran Gavin & Denis Bonner (1988)
 - Jim McDonagh (1988–89)
 - Paul McGee (1989–90)
 - Joey Malone (1990–91)
 - Tommy Lally (1991–92)
 - Tony Mannion (1992–95)
 - Denis Clarke (1995–97)
 - Don O'Riordan (1997–2001)
 - Dave Connell (2001)
 - Tony Mannion (2001–04)
 - Tommy Lally (2005)
 - Alan Gough & Jim Noone (2006)
 - Tony Cousins (2006–08)
 - Billy Clery (2008)
 - Jeff Kenna (2008–09)
 - Ian Foster (2009)
 - Sean Connor (2010–11)
 - John Brennan (2011)
 - Tommy Dunne (2013–16)
 - Shane Keegan (2016–2018)
 - Alan Murphy (2018–20)
 - John Caulfield (2020–)

