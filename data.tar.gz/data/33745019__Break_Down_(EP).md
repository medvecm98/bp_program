# Break Down (EP)

***Break Down***  is the debut Korean solo mini album of Kim Hyun-joong of South Korean boy band SS501. It was released on 7 June 2011 under KeyEast Entertainment. A Limited Edition was released on 23 June 2011, with a bonus DVD with music videos and behind-the-scene footages. The album was released in Taiwan by Warner Music Taiwan in two versions: Regular and Commemorate Editions.

## Backgroun

Kim's songs were produced by Steven Lee, who had composed SS501's hits "Love Like This" and "Love Ya". The title track "Break Down" is a high energy dance track featuring Double K. Another track, "Please" is a R&B heavy second lead track.

## Promotions

For the album, Kim promoted the high tempo dance lead track "Break Down" featuring Double K, the R&B track "제발 (Please)" and the light tempo pop song "Kiss Kiss". He had also released music videos for these three songs.

## Reception

The album exceeded 70,000 pre-ordered copies in 10 days. It peaked at number one on Gaon Weekly Album Chart for the week starting 5 June 2011 and was the best-selling album for June on Gaon Monthly Album Chart with 100,433 sales. It also topped the Oricon chart in Japan in the International Imported Album category for the first week of July.

The album's title track "Break Down" was the first-place winner for two consecutive weeks on Mnet's M! Countdown music show, for 16 and 23 June 2011; and also won for two consecutive weeks on KBS's Music Bank.

It is also certified platinum in Taiwan and Kim was presented with a platinum record by Warner Music Taiwan CEO Chen Ze Shan in a press conference held in Taiwan.

## Track listing

## Release history

## Charts

## References

 1. ^ (in Korean) "김현중씨의 1st mini album Break Down 음원 공개 및 음반 발매 안내" Archived 2012-04-25 at the Wayback Machine KeyEast Entertainment. 3 June 2011. Retrieved 2011-11-14

 2. ^ (in Korean) "김현중씨의 Break Down Limited Edition 예약판매 안내 드립니다" Archived 2012-04-25 at the Wayback Machine KeyEast Entertainment. 23 June 2011. Retrieved 2011-11-14

 3. ^ "Studio NES Official website" Archived 2014-12-09 at the Wayback Machine.Retrieved 2013-06-17.

 4. ^ "Kim Hyun-joong's 1st Solo Album Exceeds 70,000 Pre-orders" Archived 2011-09-14 at the Wayback Machine Chosun Ilbo. 1 June 2011. Retrieved 2011-10-25

 5. ^ Kim, Heidi "Gaon Weekly Album Chart: 5-11 June 2011" Archived 25 July 2013 at the Wayback Machine 10 Asia. 16 June 2011. Retrieved 2011-11-13

 6. ^ (in Korean) "김현중 앨범발매 2주만에 10만장, 올해 최다 판매량 등극" Archived 2013-07-25 at the Wayback Machine Nate News. 22 June 2011. Retrieved 2011-10-25

 7. ^ (in Korean) "김현중, 공식 팬클럽 '헤네치아' 구성" Archived 2013-07-25 at the Wayback Machine Nate News. 6 May 2011. Retrieved 2011-10-25

 8. ^ (in Chinese) "韓國首席新巨星的金賢重，14日傾盆大雨下舉辦見面會仍聚集超過2,000名粉絲" Archived 2011-10-05 at the Wayback Machine Yam News. 15 August 2011. Retrieved 2011-10-25

 9. ^ (in Chinese) "Break Down album info" Archived 2011-09-02 at the Wayback Machine Warner Music Taiwan. 1 July 2011. Retrieved 2011-11-14

 10. ^ (in Chinese) "Break Down (Commemorate Edition) album info" Archived 2011-09-02 at the Wayback Machine Warner Music Taiwan. 12 August 2011. Retrieved 2011-11-14

 11. ^ (in Korean) "This links to current week - select the week from drop down menu" Archived 2013-01-23 at the Wayback Machine Gaon Single Chart. Retrieved 2011-11-18

 12. ^ (in Korean) "This links to current week - select the week from drop down menu" Archived January 19, 2012, at the Wayback Machine Gaon Album Chart. Retrieved 2011-11-14

 13. ^ (in Korean) "This links to current week - select the year/month from drop down menu" Archived January 19, 2012, at the Wayback Machine Gaon Album Chart. Retrieved 2011-11-14

 14. ^ (in Chinese) "This links to the current week - search for week number at the bottom of page" Archived 2012-07-10 at the Wayback Machine G-Music Combo Chart. Retrieved 2011-11-16

 15. ^ (in Chinese) "This links to the current week - search for week number at the bottom of page" Archived 2011-07-22 at the Wayback Machine G-Music J-Pop/K-Pop Chart. Retrieved 2011-11-16

 16. ^ (in Chinese) "J-Pop/K-Pop Chart Week 27 (1-7 July 2011)" Archived 4 May 2015 at the Wayback Machine Five Music Chart. Retrieved 2011-11-16


## External links

 - (in Korean) Kim Hyun Joong discography

 - v
 - t
 - e

 - Discography
 - Awards and nominations

 - Unlimited
 - Imademo

 - Break Down
 - Lucky
 - Round 3
 - Timing

 - "Kiss Kiss / Lucky Guy"
 - "Heat"
 - "Tonight"
 - "Hot Sun"

 - SS501

 - MusicBrainz release group

