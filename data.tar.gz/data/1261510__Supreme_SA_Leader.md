# Supreme SA Leader



The **Supreme SA Leader**  (German: *Oberster SA-Führer* ), was the titular head of the Nazi Party's paramilitary group, the  (SA).

## History

To centralize the loyalty of the SA, Hitler personally assumed command of the entire organization in 1930 and remained  for the duration of the group's existence. After 1931, those who held the rank of , such as Ernst Röhm, were accepted as the commanders of the SA.

### Insignia

The  had no particular uniform insignia and was a paramilitary title that could be denoted in a variety of ways. Göring, for instance, created an elaborate uniform, with swastika armband accompanied with white service stripes. In contrast, Maurice wore simply a brown Nazi storm-trooper shirt with no insignia, as did Hitler when he held the title of .

## List of officeholders

## See also

 - Stabschef
 - Uniforms and insignia of the Sturmabteilung
 - List of SS personnel

## Notes

 1. ^ The NSDAP and its organs and instruments (including the Völkischer Beobachter and the SA) were banned in Bavaria (and other parts of Germany) following Hitler's abortive attempt to overthrow the Weimar Republic in the Beer Hall Putsch in November 1923. The Bavarian ban was lifted in February 1925 after Hitler pledged to adhere to legal and constitutional means in his quest for political power. See Verbotzeit. Though charged with the leadership of the SA in August 1926, Pfeffer von Salomon was not formally appointed Oberster SA-Führer until 1 November 1926.[3]

 2. ^ Pfeffer von Salomon submitted a letter of resignation on 12 August 1930, effective 29 August. Hitler accepted the resignation and named himself as Oberste SA-Führer effective 2 September.[4]


## References

 1. ^ McNab 2009, pp. 14, 15.

 2. ^ a b c McNab 2009, p. 14.

 3. ^ Miller & Schulz 2017, p. 353.

 4. ^ a b c Höffkes 1986, p. 249.


## Bibliography

 - Höffkes, Karl (1986). Hitlers Politische Generale. Die Gauleiter des Dritten Reiches: ein biographisches Nachschlagewerk. Tübingen: Grabert-Verlag. ISBN 3-87847-163-7.
 - McNab, Chris (2009). The Third Reich. Amber Books Ltd. ISBN 978-1-906626-51-8.
 - Miller, Michael D.; Schulz, Andreas (2017). Gauleiter: The Regional Leaders of the Nazi Party and Their Deputies, 1925-1945. Vol. II (Georg Joel - Dr. Bernhard Rust). R. James Bender Publishing. ISBN 978-1-932970-32-6.

 - v
 - t
 - e

 - Emil Maurice (1920–1921)
 - Hans Ulrich Klintzsch (1921–1923)
 - Hermann Göring (1923)
 - Franz Pfeffer von Salomon (1926–1930)
 - Adolf Hitler (1930–1945)

 - Otto Wagener (1929–1930)
 - Ernst Röhm (1931–1934)
 - Viktor Lutze (1934–1943)
 - Max Jüttner [de] (1943)
 - Wilhelm Schepmann (1943–1945)



This article related to Nazi Germany is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

