# Jack Rabbit Blues: The Singles of 1958–1960

***Jack Rabbit Blues***  is a compilation album of recordings by musician Ike Turner released on Secret Records in 2011. The packaging includes a 31 track CD plus a 10-inch vinyl.

In the 1950s, Turner discovered many blues musicians when he was a talent scout. He was also a bandleader and a session musician. This compilation is a selection of recordings that Turner composed and/or played on between 1958 and 1960. The artist featured in this compilation include Kenneth Churchill, Otis Rush, Betty Everett, Buddy Guy and his own band the Kings of Rhythm. It also includes the first recording of his future wife Tina Turner (Little Ann).

## Track listing

All tracks written by Ike Turner except where noted. Each track features Turner either on guitar, piano and/or vocals.

### 10 inch vinyl

## References

 1. ^ "Jack Rabbit Blues: The Singles 1958 To 1960 - Ike Turner | Songs, Reviews, Credits". AllMusic.

 2. ^ a b "Ike Turner - Jack Rabbit Blues". Discogs.

 3. ^ Turner, Ike (1999). Takin' Back My Name :The Confessions of Ike Turner. Cawthorne, Nigel. London: Virgin. ISBN 1852278501. OCLC 43321298.


 - v
 - t
 - e

 - Kings of Rhythm

 - Raymond Hill
 - Johnny O'Neal
 - Jackie Brenston
 - Willie Kizart
 - Billy Gayles
 - Erskine Oglesby
 - Clayton Love
 - Jimmy Thomas
 - Art Lassiter
 - Ernest Lane
 - Vernon Guy
 - Stacy Johnson
 - Clifford Solomon
 - Jimi Hendrix
 - Leon Blue
 - Soko Richardson
 - Patrick Gammon
 - Jeanette Bazzell Turner
 - Audrey Madison Turner

 - Ike & Tina Turner's Kings of Rhythm Dance (1962)
 - Rocks the Blues (1963)
 - A Black Man's Soul (1969)
 - Strange Fruit (1972)
 - Blues Roots (1972)
 - Bad Dreams (1973)
 - The Edge (1980)
 - Here and Now (2001)
 - Risin' with the Blues (2006)

 - I Like Ike! The Best of Ike Turner (1994)
 - The Sun Sessions (2001)
 - The Bad Man: Rare & Unreissued Ike Turner Produced Recordings 1962–1965 (2004)
 - His Woman, Her Man: The Ike Turner Diaries (2004)
 - Jack Rabbit Blues: The Singles of 1958–1960 (2011)

 - "Rocket 88" (1951)
 - "Boxtop" (1958)
 - " Box Top" (1959)
 - "Lawdy Miss Clawdy" (1972)
 - "Father Alone" (1974)

 - "How Many More Years" (1951)
 - "Moanin' at Midnight" (1951)
 - "3 O'Clock Blues" (1951)
 - "No More Doggin'" (1952)
 - "Shake It Up and Go" (1952)
 - "You Know I Love You (1952)
 - "Double Trouble" (1959)
 - "All Your Love (I Miss Loving)" (1959)
 - "Don't Throw Your Love on Me So Strong" (1961)
 - Howling Wolf Sings the Blues (1962)
 - Sweet Black Angel (1969)
 - There's a Riot Goin' On (1971)
 - "First Degree" (1997)
 - "Every Planet We Reach Is Dead" (2005)

 - Prann Records
 - Sony Records
 - Teena Records
 - Sonja Records
 - Innis Records

 - Ike Turner discography
 - Songs written by Ike Turner
 - Ike & Tina Turner
 - Ike & Tina Turner discography
 - The Ikettes
 - Bolic Sound
 - Club Imperial
 - Manhattan Club
 - What's Love Got to Do with It (1993)
 - Takin' Back My Name (1999)
 - The Road to Memphis (2003)

