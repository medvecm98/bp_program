# Tréner Ferencvárosu prvú vážnu výzvu nezvládol. Druhý gól bol ako rana dýkou

BUDAPEŠŤ. Dvakrát vyššia hodnota kádra, minimálne dvakrát väčší rozpočet, dvakrát väčšie držanie lopty.

Podľa týchto ukazovateľov mal Ferencváros v stredu večer v 2. predkole Ligy majstrov zvíťaziť nad Slovanom Bratislava.

Vo futbale však vyššia hodnota kádra, väčší rozpočet ani väčší počet útokov neznamená nevyhnutne víťazstvo. „Futbaloví bohovia niekedy prepíšu náš scenár,“ vysvetľoval po zápase Stanislav Čerčesov, tréner Ferencvárosu.

Hoci pred súbojom Slovan mnohí odpisovali, v budapeštianskej Groupama Arene vyhrali belasí 2:1.

## Weiss po góle zariskoval

Bola to zásluha tímovej mentality celého mužstva i trénerskej geniality Vladimíra Weissa. Kouč Slovana Ferencváros dokonale prečítal.

Pritom analyzoval iba jeden zápas maďarského majstra: domácu odvetu s kazašským Tobolom Kostanaj. „Videli sme nábehy a kolmé pohyby za obranu, preto som sa rozhodol hrať na troch stopérov,“ uviedol Weiss.

Proti Podbrezovej experiment nevyšiel. Tam však nehrali tí najlepší futbalisti, ktorých Slovan má.

„Tam sme to nespĺňali, ale títo hráči sú takticky vyspelejší,“ zdôraznil Weiss.

Po úvodnom góle domácich zariskoval. Zmenil systém a poslal na ihrisko viac útočných hráčov.  Slovan napokon v poslednej desaťminútovke súboj otočil. Potvrdil tak  mentálnu i fyzickú pripravenosť.

„Tréner nám niekedy hovorí, že  nebeháme, ale tentoraz takúto kritiku neprijmem,“ smial sa autor prvého  gólu belasých Guram Kašia.

„Hovoril som o niektorých hráčoch,“ reagoval s úsmevom aj Weiss a dôraz kládol na slovíčko „niektorí“.

Tréner Slovana bol na tlačovej konferencii uvoľnený, hoci stále prízvukoval, že sú iba v polovici súboja.

Chválil svojich hráčov, vyzdvihol aj krásny víťazný gól Tigrana Barseghyana.  "Podali sme komplexný výkon, teraz sa musíme fantasticky pripraviť na  odvetu," uviedol Weiss.
