# Colisée Cardin

The **Colisée Cardin**  is an indoor arena located in Sorel-Tracy, Quebec. It was built in 1954 and has a capacity of 3,037 people. It once hosted the Sorel Éperviers of the QMJHL. The arena's primary tenant today are the Sorel-Tracy Éperviers of the LNAH.



This article about a Canadian ice hockey arena is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

This article about a building or structure in Quebec is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

This article about a sports venue in Canada is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

