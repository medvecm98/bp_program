# Esmond Mountain

**Esmond Mountain**  is a summit in the U.S. state of Oregon. The elevation is 4,895 feet (1,492 m).

Esmond Mountain was named after Edwin Esmond, a pioneer settler.

## References

 1. ^ a b U.S. Geological Survey Geographic Names Information System: Esmond Mountain

 2. ^ "Jackson County Place Names Database". Jackson County Genealogy Library. Archived from the original on 4 October 2018. Retrieved 29 May 2019.






This Jackson County, Oregon state location article is a stub. You can help Wikipedia by expanding it.
 - v
 - t
 - e

