# List of shipwrecks in August 1863


The **list of shipwrecks in August 1863**  includes ships sunk, foundered, grounded, or otherwise lost during August 1863.

## 1 Augus

## 2 Augus

## 3 Augus

## 4 Augus

## 5 Augus

## 6 Augus

## 7 Augus

## 8 Augus

## 9 Augus

## 10 Augus

## 11 Augus

## 12 Augus

## 13 Augus

## 14 Augus

## 15 Augus

## 16 Augus

## 17 Augus

## 18 Augus

## 19 Augus

## 20 Augus

## 21 Augus

## 22 Augus

## 23 Augus

## 24 Augus

## 25 Augus

## 26 Augus

## 27 Augus

## 28 Augus

## 29 Augus

## 30 Augus

## 31 Augus

## Unknown da

## References

### Notes

 1. ^ a b c d "Shipping Intelligence". Liverpool Mercury. No. 4848. Liverpool. 24 August 1863.

 2. ^ a b c d "Shipping Intelligence". Liverpool Mercury. No. 4387. Liverpool. 11 August 1863.

 3. ^ a b c d e f "Mercantile Ship News". The Standard. No. 12168. London. 11 August 1863. p. 7.

 4. ^ "Shipping Intelligence". Liverpool Mercury. No. 4894. Liverpool. 17 October 1863.

 5. ^ a b "Mercantile Ship News". The Standard. No. 12201. London. 18 September 1863. p. 8.

 6. ^ a b "Shipping Intelligence". Caledonian Mercury. No. 23129. Edinburgh. 22 August 1863.

 7. ^ a b c d e f "Ship News". The Times. No. 24652. London. 1 September 1863. col F, p. 12.

 8. ^ "Shipping Intelligence". Glasgow Herald. No. 7378. Glasgow. 2 September 1863.

 9. ^ a b c "Marine Intelligence". Newcastle Courant. No. 9842. London. 14 August 1863.

 10. ^ "The Bombay and Mauritius Mails". The Times. No. 24633. London. 10 August 1863. col F, p. 7.

 11. ^ "Shipping Intelligence". Caledonian Mercury. No. 23153. Edinburgh. 19 September 1863.

 12. ^ "Loss of a China Ship with a Cargo valued at £100,000". The Era. No. 1304. London. 20 September 1863.

 13. ^ "Shipping Intelligence". Aberdeen Journal. No. 6043. Aberdeen. 4 November 1863.

 14. ^ a b "Dundee Shipping". Dundee Courier. No. 3119. Dundee. 8 August 1863.

 15. ^ "Shipping Intelligence". Liverpool Mercury. No. 4834. Liverpool. 7 August 1863.

 16. ^ a b c "Shipping Intelligence". Caledonian Mercury. No. 23117. Edinburgh. 8 August 1863.

 17. ^ "Americe". The Times. No. 24650. London. 29 August 1863. col B-D, p. 12.

 18. ^ "Georgia". Shipping & Shipbuilding Research Trust. Retrieved 25 March 2020.

 19. ^ a b "Shipping Intelligence". Liverpool Mercury. No. 4858. Liverpool. 4 September 1863.

 20. ^ "Shipping Intelligence". Caledonian Mercury. No. 23141. Edinburgh. 5 September 1863.

 21. ^ Gaines, p. 102.

 22. ^ a b c d e "Mercantile Ship News". The Standard. No. 12178. London. 22 August 1863. p. 7.

 23. ^ a b c d "Marine Intelligence". Newcastle Courant. No. 9844. Newcastle upon Tyne. 28 August 1863.

 24. ^ a b "Shipping Intelligence". Liverpool Mercury. No. 4860. Liverpool. 7 September 1863.

 25. ^ "Mercantile Ship News". The Standard. No. 12208. London. 26 September 1863. p. 7.

 26. ^ "Shipping Intelligence". Liverpool Mercury. No. 4840. Liverpool. 14 August 1863.

 27. ^ a b "Shipping Intelligence". Caledonian Mercury. No. 23123. Edinburgh. 15 August 1863.

 28. ^ a b "Shipping Intelligence". Liverpool Mercury. No. 6032. Liverpool. 19 August 1863.

 29. ^ Gaines, p. 145.

 30. ^ a b c d e "Mercantile Ship News". The Standard. No. 12175. London. 19 August 1863. p. 8.

 31. ^ a b c d e f "Mercantile Ship News". The Standard. No. 12180. London. 25 August 1863. p. 8.

 32. ^ "The India, China, and Australian Mails". The Times. No. 24668. London. 19 September 1863. col F, p. 6.

 33. ^ a b c d e f "Mercantile Ship News". The Standard. No. 12179. London. 24 August 1863. p. 8.

 34. ^ a b c d e f g "Ship News". The Times. No. 24646. London. 25 August 1863. col F, p. 8.

 35. ^ Gaines, p. 140.

 36. ^ "Shipping Intelligence". Liverpool Mercury. No. 4855. Liverpool. 1 September 1863.

 37. ^ a b c d e "Mercantile Ship News". The Standard. No. 12186. London. 1 September 1863. p. 8.

 38. ^ a b c d "Mercantile Ship News". The Standard. No. 12173. London. 17 August 1863. p. 8.

 39. ^ "Shipping Intelligence". Liverpool Mercury. No. 4880. Liverpool. 30 September 1863.

 40. ^ a b c d "Shipping Intelligence". Caledonian Mercrury. No. 23126. Edinburgh. 19 August 1863.

 41. ^ a b "Mercantile Ship News". The Standard. No. 12198. London. 15 September 1863. p. 7.

 42. ^ a b "Shipping Intelligence". Liverpool Mercury. No. 4839. Liverpool. 13 August 1863.

 43. ^ a b "Marine Intelligence". Newcastle Courant. No. 9843. Newcastle upon Tyne. 17 August 1863.

 44. ^ a b c Ingram & Wheatley, p. 92.

 45. ^ "Foreign Intelligence". The Times. No. 25163. London. 19 April 1865. col C-D, p. 9.

 46. ^ a b "Shipping Intelligence". Liverpool Mercury. No. 4893. Liverpool. 18 October 1863.

 47. ^ "Shipping Intelligence". Caledonian Mercury. No. 23176. Edinburgh. 16 October 1863.

 48. ^ "Shipping Intelligence". Liverpool Mercury. No. 4854. Liverpool. 11 September 1863.

 49. ^ a b "Ship News". The Times. No. 24641. London. 19 August 1863. col C, p. 12.

 50. ^ "Shipping Intelligence". Liverpool Mercury. No. 4906. Liverpool. 30 October 1863.

 51. ^ "Wreck of a Passenger Steamer off the Isle of Wight". The Standard. No. 12173. London. 17 August 1863. p. 2.

 52. ^ "Naval and Military Intelligence". The Standard. No. 12175. London. 19 August 1863. p. 3.

 53. ^ a b c "Mercantile Ship News". The Standard. No. 12192. London. 8 September 1863. p. 8.

 54. ^ a b "Shipping Intelligence". Liverpool Mercury. No. 4850. Liverpool. 26 August 1863.

 55. ^ "Dundee Shipping". Dundee Courier. No. 3206. Dundee. 18 November 1863.

 56. ^ "A Vessel Crushed by Ice - Dreadful Sufferings of the Crew". The Standard. No. 12254. London. 2 November 1863. p. 2.

 57. ^ Gaines, p. 117.

 58. ^ a b "Mercantile Ship News". The Standard. No. 12325. London. 10 February 1864. p. 7.

 59. ^ a b "Shippin Intelligence". Caledonian Mercury. No. 23150. Edinburgh. 16 September 1863.

 60. ^ a b c d e f g h usnlp.org Navy Chronology of the Civil War, July-December 1863

 61. ^ Gaines, p. 121.

 62. ^ "Greenock". Glasgow Herald. No. 7370. Glasgow. 24 August 1863.

 63. ^ Gaines, p. 43.

 64. ^ a b c "Shipping Intelligence". Liverpool Mercury. No. 4846. Liverpool. 21 August 1863.

 65. ^ a b "Mercantile Ship News". The Standard. No. 12253. London. 17 November 1863. p. 7.

 66. ^ a b "Mercantile Ship News". The Standard. No. 12185. London. 31 August 1863. p. 8.

 67. ^ "Shipping Intelligence". Liverpool Mercury. No. 4921. Liverpool. 17 November 1863.

 68. ^ Gaines, p. 50.

 69. ^ Silverstone, Paul H., Civil War Navies, 1855-1883, New York: Routledge/Taylor & Francis, 2006, ISBN 0-415-97870-X, p. 180.

 70. ^ a b "Shipping Intelligence". Caledonian Mercury. No. 23133. Edinburgh. 27 August 1863.

 71. ^ a b "Shipping Intelligence". Liverpool Mercury. No. 4849. Liverpool. 25 August 1863.

 72. ^ Gaines, p. 56.

 73. ^ Ahoy - Mac's Web Log "Marauders of the Sea, Confederate Merchant Raiders During the American Civil War: CSS Florida. 1862-1863. Captain John Newland Maffitt. CSS Florida. 1864. Captain Charles M. Morris"

 74. ^ Gaines, p. 36.

 75. ^ Gaines, p. 114.

 76. ^ Gaines, p. 92.

 77. ^ "Shipping Intelligence". Caledonian Mercury. No. 23132. Edinburgh. 26 August 1863.

 78. ^ a b "Mercantile Ship News". The Standard. No. 12182. London. 27 August 1863. p. 8.

 79. ^ "Shipping Intelligence". Liverpool Mercury. No. 4847. Liverpool. 22 August 1863.

 80. ^ "Mercantile Ship News". The Standard. No. 12279. London. 18 December 1863. p. 7.

 81. ^ "Marine Intelligence". Newcastle Courant. No. 9850. Newcastle upon Tyne. 9 October 1863.

 82. ^ Gaines, p. 120.

 83. ^ Gaines, p. 132.

 84. ^ "Ship News". The Times. No. 24662. London. 12 September 1863. col F, p. 6.

 85. ^ "Pier Head, Dublin". Freeman's Journal. Dublin. 25 August 1863.

 86. ^ Gaines, p. 181.

 87. ^ "Mercantile Ship News". The Standard. No. 12195. London. 11 September 1863. p. 7.

 88. ^ "Mercantile Ship News". The Standard. No. 12199. London. 16 September 1863. p. 8.

 89. ^ a b "Shipping Intelligence". Liverpool Mercury. No. 4889. Liverpool. 10 October 1863.

 90. ^ a b "Marine Intelligence". Newcastle Courant. No. 9845. Newcastle upon Tyne. 4 September 1863.

 91. ^ "Telegraphic Intelligence". Daily News. No. 5421. London. 23 September 1863.

 92. ^ "Marine Intelligence". Newcastle Courant. No. 9847. Newcastle upon Tyne. 18 September 1863.

 93. ^ "Fortunate Rescue at Sea". Morning Post. No. 27991. London. September 1863. p. 5.

 94. ^ Gaines, p. 165.

 95. ^ Gaines, p. 57.

 96. ^ a b "Dundee Shipping". Dundee Courier. No. 3142. Dundee. 4 September 1863.

 97. ^ "Shipping Intelligence". Belfast News-Letter. No. 32578. Belfast. 21 September 1863.

 98. ^ "Shipping Intelligence". Caledonian Mercury. No. 23149. Edinburgh. 15 September 1863.

 99. ^ "Mercantile Ship News". The Standard. No. 12200. London. 17 September 1863. p. 7.

 100. ^ a b c "Shipping Intelligence". Caledonian Mercury. No. 23139. Edinburgh. 3 September 1863.

 101. ^ Renno, David (2004). Beachy Head Shipwrecks of the 19th Century. Sevenoaks: Amhurst Publishing. pp. 216–17. ISBN 1-903637-20-1.

 102. ^ Gaines, p. 177.

 103. ^ a b "Shipping Intelligence". Liverpool Mercury. No. 4838. Liverpool. 12 August 1863.

 104. ^ "Shipping Intelligence". Caledonian Mercury. No. 23146. Edinburgh. 11 September 1863.

 105. ^ Gaines, p. 187.

 106. ^ "Shipping Intelligence". Caledonian Mercury. No. 23137. Edinburgh. 1 September 1863.

 107. ^ a b Gaines, pp. 187-188.

 108. ^ Naval History and Heritage Command: Confederate Ships: Sharp

 109. ^ Gaines, p. 156.

 110. ^ Gaines, p. 189.

 111. ^ Gaines, p. 192.


### Bibliography

 - Gaines, W. Craig, Encyclopedia of Civil War Shipwrecks, Louisiana State University Press, 2008 Archived 29 November 2010 at the Wayback Machine, ISBN 978-0-8071-3274-6.
 - Ingram, C. W. N., and Wheatley, P. O., (1936) Shipwrecks: New Zealand disasters 1795–1936. Dunedin, NZ: Dunedin Book Publishing Association.

 - v
 - t
 - e

 - 1858
 - 1859
 - 1860
 - 1861
 - 1862
 - 1863
 - 1864
 - 1865
 - 1866
 - 1867
 - 1868

 - 1858
 - 1859
 - 1860
 - 1861
 - 1862
 - 1863
 - 1864
 - 1865
 - 1866
 - 1867
 - 1868

 - 1858
 - 1859
 - 1860
 - 1861
 - 1862
 - 1863
 - 1864
 - 1865
 - 1866
 - 1867
 - 1868

 - 1858
 - 1859
 - 1860
 - 1861
 - 1862
 - 1863
 - 1864
 - 1865
 - 1866
 - 1867
 - 1868

 - v
 - t
 - e

 - Jan
 - Feb
 - Mar
 - Apr
 - May
 - Jun
 - Jul
 - Aug
 - Sep
 - Oct
 - Nov
 - Dec
 - Unknown date

 - Jan
 - Feb
 - Mar
 - Apr
 - May
 - Jun
 - Jul
 - Aug
 - Sep
 - Oct
 - Nov
 - Dec
 - Unknown date

 - Jan
 - Feb
 - Mar
 - Apr
 - May
 - Jun
 - Jul
 - Aug
 - Sep
 - Oct
 - Nov
 - Dec
 - Unknown date

 - Jan
 - Feb
 - Mar
 - Apr
 - May
 - Jun
 - Jul
 - Aug
 - Sep
 - Oct
 - Nov
 - Dec
 - Unknown date

 - Jan
 - Feb
 - Mar
 - Apr
 - May
 - Jun
 - Jul
 - Aug
 - Sep
 - Oct
 - Nov
 - Dec
 - Unknown date

 - Jan
 - Feb
 - Mar
 - Apr
 - May
 - Jun
 - Jul
 - Aug
 - Sep
 - Oct
 - Nov
 - Dec
 - Unknown date

 - Jan
 - Feb
 - Mar
 - Apr
 - May
 - Jun
 - Jul
 - Aug
 - Sep
 - Oct
 - Nov
 - Dec
 - Unknown date

 - Jan
 - Feb
 - Mar
 - Apr
 - May
 - Jun
 - Jul
 - Aug
 - Sep
 - Oct
 - Nov
 - Dec
 - Unknown date

 - Jan
 - Feb
 - Mar
 - Apr
 - May
 - Jun
 - Jul
 - Aug
 - Sep
 - Oct
 - Nov
 - Dec
 - Unknown date

 - Jan
 - Feb
 - Mar
 - Apr
 - May
 - Jun
 - Jul
 - Aug
 - Sep
 - Oct
 - Nov
 - Dec
 - Unknown date



