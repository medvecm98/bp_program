# Heger hľadá výhovorky (komentár)

V lete ťažko udržať čokoľvek čerstvé, a tak aj argumenty okolo koaličnej krízy nám začali kvasiť a púšťať šťavu do verejného priestoru. Povenujme sa tomu, ktorý viní SaS zo zištného vyvolania krízy, na čom má zbierať prieskumové bodíky.

Premiér Heger to nehovorí takto príkro, ale spolieha sa, že keď bude opakovať tézu o tom, že SaS mohla balíček vetovať a neurobila to, poslucháč si to takto vyvodí.

Že zloprajné SaS nepoužilo veto, aby škaredo vmanipulovalo obyčajných do situácie, keď nemohli inak, ako hlasovať s fašistami. A potom ich za to ešte okrikovali. Ak by im balíček skutočne prekážal, mali sa ozvať vtedy, tvrdí Heger.

V poriadku, chápeme, že hnutie s lídrom, ktorého nedôvera sa blíži k 90 percentám, sa môže cítiť obložené neprajníkmi až záškodníkmi. A keďže odmieta hľadať problém v samotnom lídrovi, lebo ten je vraj síce aj trochu ostrý, aj chvíľami neslušný, ale najmä je – slovami Beaty Dubasovej – taký, aký je, musí sa rozhliadať naokolo.
